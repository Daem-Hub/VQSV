@echo off
setlocal
chcp 65001 >nul

set "CLIENT_ROOT=%~dp0"
set "CLIENT_ROOT=%CLIENT_ROOT:~0,-1%"
set "CLIENT_EXE=%CLIENT_ROOT%\VQSV Liet Hoa Rebuild.exe"
set "PACKAGED_JAVA=%CLIENT_ROOT%\runtime\bin\java.exe"
set "CLIENT_JAVA=%PACKAGED_JAVA%"
set "CLIENT_JAR=%CLIENT_ROOT%\app\vqsv-liet-hoa-rebuild.jar"
set "CLIENT_MODULES=%CLIENT_ROOT%\app\modules"
set "CLIENT_TRACE=%CLIENT_ROOT%\vqsv-movement-trace.log"
set "VQSV_MOVEMENT_TRACE=%CLIENT_TRACE%"
cd /d "%CLIENT_ROOT%"

echo [VQSV] Client root: %CLIENT_ROOT%
echo [VQSV] Client exe:  %CLIENT_EXE%
echo [VQSV] Movement trace: %CLIENT_TRACE%
del "%CLIENT_TRACE%" >nul 2>nul

if /i "%~1"=="--exe" (
    if not exist "%CLIENT_EXE%" (
        echo [VQSV] Missing exe: %CLIENT_EXE%
        pause
        exit /b 1
    )
    echo [VQSV] Running packaged launcher exe.
    shift /1
    "%CLIENT_EXE%" %*
    set "EXIT_CODE=%ERRORLEVEL%"
    echo [VQSV] Exe exited with code %EXIT_CODE%
    pause
    exit /b %EXIT_CODE%
)

if not exist "%CLIENT_JAVA%" (
    set "CLIENT_JAVA="
    for /f "delims=" %%J in ('where java.exe 2^>nul') do if not defined CLIENT_JAVA set "CLIENT_JAVA=%%J"
)
if not defined CLIENT_JAVA (
    echo [VQSV] Missing console Java runner.
    echo [VQSV] Packaged runtime has no java.exe: %PACKAGED_JAVA%
    echo [VQSV] Install a JDK/JRE on PATH, or use "run.bat --exe".
    pause
    exit /b 1
)
if not exist "%CLIENT_JAR%" (
    echo [VQSV] Missing client jar: %CLIENT_JAR%
    pause
    exit /b 1
)
if not exist "%CLIENT_MODULES%" (
    echo [VQSV] Missing modules root: %CLIENT_MODULES%
    pause
    exit /b 1
)

echo [VQSV] Running client in console-log mode.
echo [VQSV] Java runner: %CLIENT_JAVA%
echo [VQSV] Battle target trace: enabled ([TARGET-TRACE])
echo [VQSV] Use "run.bat --exe" to launch through the packaged exe instead.
"%CLIENT_JAVA%" "-Dvqsv.modules=%CLIENT_MODULES%" "-Dvqsv.movementTrace=%CLIENT_TRACE%" "-Dvqsv.targetTrace=true" -cp "%CLIENT_JAR%" vqsv.Main %*
set "EXIT_CODE=%ERRORLEVEL%"
echo [VQSV] Client exited with code %EXIT_CODE%
pause
exit /b %EXIT_CODE%
